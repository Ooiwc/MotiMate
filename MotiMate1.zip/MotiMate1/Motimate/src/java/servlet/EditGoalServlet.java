package servlet;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.*;
import model.Goal;
import model.User;
import util.DBConnection;

@WebServlet("/edit")
public class EditGoalServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        String oldDescription = request.getParameter("oldDescription");
        String oldType = request.getParameter("oldType");

        HttpSession session = request.getSession();
        @SuppressWarnings("unchecked")
        Map<String, List<Goal>> goalMap = (Map<String, List<Goal>>) session.getAttribute("goalMap");
        @SuppressWarnings("unchecked")
        Set<String> earnedRewards = (Set<String>) session.getAttribute("earnedRewards");
        User user = (User) session.getAttribute("user");

        if (user == null) {
            request.setAttribute("error", "User not logged in. Please log in to edit goals.");
            response.sendRedirect("login.jsp");
            return;
        }

        if (goalMap == null) {
            goalMap = new HashMap<>();
            goalMap.put("Daily", new ArrayList<>());
            goalMap.put("Weekly", new ArrayList<>());
            goalMap.put("Monthly", new ArrayList<>());
            session.setAttribute("goalMap", goalMap);
        }

        if (earnedRewards == null) {
            earnedRewards = new HashSet<>();
            session.setAttribute("earnedRewards", earnedRewards);
        }

        if ("delete".equals(action)) {
            List<Goal> goals = goalMap.get(oldType);
            if (goals != null) {
                goals.removeIf(g -> g.getDescription().equals(oldDescription));
                session.setAttribute("goalMap", goalMap);
                // Delete from GOALS table
                try (Connection conn = DBConnection.getConnection();
                     PreparedStatement stmt = conn.prepareStatement(
                         "DELETE FROM GOALS WHERE USER_ID = ? AND TYPE = ? AND DESCRIPTION = ?")) {
                    stmt.setInt(1, user.getUserId());
                    stmt.setString(2, oldType);
                    stmt.setString(3, oldDescription);
                    stmt.executeUpdate();
                } catch (SQLException e) {
                    e.printStackTrace();
                    request.setAttribute("error", "Database error: Unable to delete goal - " + e.getMessage());
                    response.sendRedirect("edit.jsp");
                    return;
                }
                recalculateRewards(goalMap, earnedRewards);
                session.setAttribute("earnedRewards", earnedRewards);
            }
            response.sendRedirect("edit.jsp");
            return;
        }

        if ("update".equals(action)) {
            String newDescription = request.getParameter("newDescription");
            String newType = request.getParameter("newType");
            String newDeadline = request.getParameter("newDeadline");

            int maxGoals;
            switch (newType) {
                case "Daily": maxGoals = 3; break;
                case "Weekly": maxGoals = 7; break;
                case "Monthly": maxGoals = 15; break;
                default: maxGoals = 3; break;
            }

            // Check max goals in the database
            try (Connection conn = DBConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(
                     "SELECT COUNT(*) FROM GOALS WHERE USER_ID = ? AND TYPE = ?")) {
                stmt.setInt(1, user.getUserId());
                stmt.setString(2, newType);
                ResultSet rs = stmt.executeQuery();
                int currentCount = 0;
                if (rs.next()) {
                    currentCount = rs.getInt(1);
                }
                if (oldType.equals(newType)) {
                    // If type hasn't changed, exclude the current goal from the count
                    try (PreparedStatement stmt2 = conn.prepareStatement(
                         "SELECT COUNT(*) FROM GOALS WHERE USER_ID = ? AND TYPE = ? AND DESCRIPTION = ?")) {
                        stmt2.setInt(1, user.getUserId());
                        stmt2.setString(2, oldType);
                        stmt2.setString(3, oldDescription);
                        ResultSet rs2 = stmt2.executeQuery();
                        if (rs2.next() && rs2.getInt(1) > 0) {
                            currentCount--;
                        }
                    }
                }
                if (currentCount >= maxGoals) {
                    request.setAttribute("error", "Maximum number of " + newType + " goals (" + maxGoals + ") reached.");
                    response.setContentType("text/html;charset=UTF-8");
                    response.getWriter().println("<script>alert('Maximum number of " + newType + " goals (" + maxGoals + ") reached.'); window.location='edit.jsp';</script>");
                    return;
                }
            } catch (SQLException e) {
                e.printStackTrace();
                request.setAttribute("error", "Database error: Unable to check goal limits - " + e.getMessage());
                response.sendRedirect("edit.jsp");
                return;
            }

            // Check for duplicate deadline in the database
            boolean duplicateTime = false;
            try (Connection conn = DBConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(
                     "SELECT COUNT(*) FROM GOALS WHERE USER_ID = ? AND DEADLINE = ? AND NOT (TYPE = ? AND DESCRIPTION = ?)")) {
                stmt.setInt(1, user.getUserId());
                stmt.setTime(2, java.sql.Time.valueOf(newDeadline + ":00"));
                stmt.setString(3, oldType);
                stmt.setString(4, oldDescription);
                ResultSet rs = stmt.executeQuery();
                if (rs.next() && rs.getInt(1) > 0) {
                    duplicateTime = true;
                }
            } catch (SQLException e) {
                e.printStackTrace();
                request.setAttribute("error", "Database error: Unable to check for duplicate deadlines - " + e.getMessage());
                response.sendRedirect("edit.jsp");
                return;
            }

            if (duplicateTime) {
                request.setAttribute("error", "A goal is already set for this time. Please choose another time.");
                response.setContentType("text/html;charset=UTF-8");
                response.getWriter().println("<script>alert('A goal is already set for this time. Please choose another time.'); window.location='edit.jsp';</script>");
                return;
            }

            List<Goal> oldGoals = goalMap.get(oldType);
            Goal targetGoal = null;
            if (oldGoals != null) {
                for (Goal g : oldGoals) {
                    if (g.getDescription().equals(oldDescription)) {
                        targetGoal = g;
                        break;
                    }
                }
            }

            if (targetGoal != null) {
                oldGoals.remove(targetGoal);
                String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
                int maxCount;
                switch (newType) {
                    case "Daily": maxCount = 1; break;
                    case "Weekly": maxCount = 7; break;
                    case "Monthly": maxCount = 30; break;
                    default: maxCount = 1; break;
                }
                Goal updatedGoal = new Goal(newDescription, timestamp, newDeadline, maxCount);
                updatedGoal.setCompletedCount(0);
                updatedGoal.setCompleted(false);

                List<Goal> newGoals = goalMap.get(newType);
                if (newGoals == null) {
                    newGoals = new ArrayList<>();
                    goalMap.put(newType, newGoals);
                }
                newGoals.add(updatedGoal);
                session.setAttribute("goalMap", goalMap);

                // Update the GOALS table
                try (Connection conn = DBConnection.getConnection();
                     PreparedStatement stmt = conn.prepareStatement(
                         "UPDATE GOALS SET DESCRIPTION = ?, TYPE = ?, TIMESTAMP = ?, DEADLINE = ?, MAX_COUNT = ?, COMPLETED_COUNT = ?, COMPLETED = ? WHERE USER_ID = ? AND TYPE = ? AND DESCRIPTION = ?")) {
                    stmt.setString(1, newDescription);
                    stmt.setString(2, newType);
                    stmt.setTimestamp(3, java.sql.Timestamp.valueOf(timestamp));
                    stmt.setTime(4, java.sql.Time.valueOf(newDeadline + ":00"));
                    stmt.setInt(5, maxCount);
                    stmt.setInt(6, 0);
                    stmt.setBoolean(7, false);
                    stmt.setInt(8, user.getUserId());
                    stmt.setString(9, oldType);
                    stmt.setString(10, oldDescription);
                    int affectedRows = stmt.executeUpdate();
                    if (affectedRows == 0) {
                        // If update fails (e.g., goal not found), insert as new
                        try (PreparedStatement insertStmt = conn.prepareStatement(
                             "INSERT INTO GOALS (USER_ID, DESCRIPTION, TYPE, TIMESTAMP, DEADLINE, MAX_COUNT, COMPLETED_COUNT, COMPLETED) VALUES (?, ?, ?, ?, ?, ?, ?, ?)")) {
                            insertStmt.setInt(1, user.getUserId());
                            insertStmt.setString(2, newDescription);
                            insertStmt.setString(3, newType);
                            insertStmt.setTimestamp(4, java.sql.Timestamp.valueOf(timestamp));
                            insertStmt.setTime(5, java.sql.Time.valueOf(newDeadline + ":00"));
                            insertStmt.setInt(6, maxCount);
                            insertStmt.setInt(7, 0);
                            insertStmt.setBoolean(8, false);
                            insertStmt.executeUpdate();
                        }
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                    request.setAttribute("error", "Database error: Unable to update goal - " + e.getMessage());
                    response.sendRedirect("edit.jsp");
                    return;
                }

                recalculateRewards(goalMap, earnedRewards);
                session.setAttribute("earnedRewards", earnedRewards);
            }
            response.sendRedirect("edit.jsp");
        }
    }

    private void recalculateRewards(Map<String, List<Goal>> goalMap, Set<String> earnedRewards) {
        Map<String, Integer> completedGoalsMap = new HashMap<>();
        for (String type : Arrays.asList("Daily", "Weekly", "Monthly")) {
            List<Goal> typeGoals = goalMap.get(type);
            int completedCount = 0;
            if (typeGoals != null) {
                for (Goal g : typeGoals) {
                    if (g.isCompleted()) {
                        completedCount++;
                    }
                }
            }
            completedGoalsMap.put(type, completedCount);
        }

        Set<String> rewardsToRemove = new HashSet<>();
        if (completedGoalsMap.get("Daily") < 3) {
            rewardsToRemove.add("IMG/DailyReward.jpeg");
        }
        if (completedGoalsMap.get("Weekly") < 4) {
            rewardsToRemove.add("IMG/WeeklyReward1.jpeg");
        }
        if (completedGoalsMap.get("Weekly") < 7) {
            rewardsToRemove.add("IMG/WeeklyReward2.jpeg");
        }
        if (completedGoalsMap.get("Monthly") < 5) {
            rewardsToRemove.add("IMG/MonthlyReward1.jpeg");
        }
        if (completedGoalsMap.get("Monthly") < 10) {
            rewardsToRemove.add("IMG/MonthlyReward2.jpeg");
        }
        if (completedGoalsMap.get("Monthly") < 15) {
            rewardsToRemove.add("IMG/MonthlyReward3.jpeg");
        }

        earnedRewards.removeAll(rewardsToRemove);
    }
}