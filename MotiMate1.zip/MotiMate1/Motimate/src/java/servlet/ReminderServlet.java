package servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import model.User;
import util.DBConnection;

@WebServlet("/reminder")
public class ReminderServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Log entry to confirm servlet is called
        System.out.println("ReminderServlet: Received POST request");

        User user = (User) request.getSession().getAttribute("user");
        if (user == null) {
            System.out.println("ReminderServlet: User not found in session, redirecting to login.jsp");
            response.sendRedirect("login.jsp");
            return;
        }
        System.out.println("ReminderServlet: User ID = " + user.getUserId());

        @SuppressWarnings("unchecked")
        Map<String, Map<String, Object>> reminders = (Map<String, Map<String, Object>>) request.getSession().getAttribute("reminders");
        if (reminders == null) {
            reminders = new HashMap<>();
            request.getSession().setAttribute("reminders", reminders);
        }

        // Log form parameters
        String goalDesc = request.getParameter("goalDesc");
        String goalType = request.getParameter("goalType");
        String daysBefore = request.getParameter("daysBefore");
        String hoursBefore = request.getParameter("hoursBefore");
        String reminderTime = request.getParameter("reminderTime");
        String soundType = request.getParameter("soundType");
        String customMessage = request.getParameter("customMessage");

        System.out.println("ReminderServlet: goalDesc = " + goalDesc);
        System.out.println("ReminderServlet: goalType = " + goalType);
        System.out.println("ReminderServlet: daysBefore = " + daysBefore);
        System.out.println("ReminderServlet: hoursBefore = " + hoursBefore);
        System.out.println("ReminderServlet: reminderTime = " + reminderTime);
        System.out.println("ReminderServlet: soundType = " + soundType);
        System.out.println("ReminderServlet: customMessage = " + customMessage);

        if (goalDesc == null || goalType == null || goalDesc.trim().isEmpty() || goalType.trim().isEmpty()) {
            System.out.println("ReminderServlet: Missing required fields");
            request.setAttribute("error", "Please select a goal and goal type.");
            response.sendRedirect("gentleReminders.jsp");
            return;
        }

        // Validate and set reminder settings
        Map<String, Object> reminderSettings = new HashMap<>();
        reminderSettings.put("daysBefore", daysBefore != null && !daysBefore.trim().isEmpty() ? Integer.parseInt(daysBefore) : 0);
        reminderSettings.put("hoursBefore", hoursBefore != null && !hoursBefore.trim().isEmpty() ? Integer.parseInt(hoursBefore) : 0);
        reminderSettings.put("reminderTime", reminderTime != null && !reminderTime.trim().isEmpty() ? reminderTime : null);
        reminderSettings.put("soundType", soundType != null ? soundType : "sms-185447.mp3");
        reminderSettings.put("customMessage", customMessage != null ? customMessage : "");

        String key = goalType + "_" + goalDesc;
        reminders.put(key, reminderSettings);
        request.getSession().setAttribute("reminders", reminders);

        // Persist to REMINDERS table
        try (Connection conn = DBConnection.getConnection()) {
            System.out.println("ReminderServlet: Database connection established");
            String sql = "INSERT INTO REMINDERS (USER_ID, GOAL_DESCRIPTION, GOAL_TYPE, DAYS_BEFORE, HOURS_BEFORE, REMINDER_TIME, SOUND_TYPE, CUSTOM_MESSAGE) VALUES (?, ?, ?, ?, ?, ?, ?, ?) " +
                         "ON DUPLICATE KEY UPDATE DAYS_BEFORE = VALUES(DAYS_BEFORE), HOURS_BEFORE = VALUES(HOURS_BEFORE), REMINDER_TIME = VALUES(REMINDER_TIME), " +
                         "SOUND_TYPE = VALUES(SOUND_TYPE), CUSTOM_MESSAGE = VALUES(CUSTOM_MESSAGE)";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, user.getUserId());
                stmt.setString(2, goalDesc);
                stmt.setString(3, goalType);
                stmt.setInt(4, (int) reminderSettings.get("daysBefore"));
                stmt.setInt(5, (int) reminderSettings.get("hoursBefore"));
                stmt.setString(6, (String) reminderSettings.get("reminderTime"));
                stmt.setString(7, (String) reminderSettings.get("soundType"));
                stmt.setString(8, (String) reminderSettings.get("customMessage"));
                int rowsAffected = stmt.executeUpdate();
                System.out.println("ReminderServlet: Rows affected = " + rowsAffected);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("ReminderServlet: SQLException - " + e.getMessage());
            request.setAttribute("error", "Database error: Unable to save reminder - " + e.getMessage());
            response.sendRedirect("gentleReminders.jsp");
            return;
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("ReminderServlet: Unexpected error - " + e.getMessage());
            request.setAttribute("error", "Unexpected error: " + e.getMessage());
            response.sendRedirect("gentleReminders.jsp");
            return;
        }

        System.out.println("ReminderServlet: Redirecting to gentleReminders.jsp");
        response.sendRedirect("gentleReminders.jsp");
    }
}