/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlet;

import model.Goal;
import jakarta.servlet.annotation.WebServlet;
import java.util.*;

/**
 *
 * @author zijie
 */
@WebServlet(name = "RewardService", urlPatterns = {"/RewardService"})
public class RewardService {
    public static void recalculateRewards(Map<String, List<Goal>> goalMap, Set<String> earnedRewards) {
        Map<String, Integer> completedGoalsMap = new HashMap<>();
        for (String type : Arrays.asList("Daily", "Weekly", "Monthly")) {
            List<Goal> goals = goalMap.get(type);
            int completedCount = 0;
            if (goals != null) {
                for (Goal g : goals) {
                    if (g.isCompleted()) {
                        completedCount++;
                    }
                }
            }
            completedGoalsMap.put(type, completedCount);
        }

        Set<String> rewardsToRemove = new HashSet<>();
        if (completedGoalsMap.get("Daily") < 3) {
            rewardsToRemove.add("IMG/DailyReward.jpeg");
        }
        if (completedGoalsMap.get("Weekly") < 4) {
            rewardsToRemove.add("IMG/WeeklyReward1.jpeg");
        }
        if (completedGoalsMap.get("Weekly") < 7) {
            rewardsToRemove.add("IMG/WeeklyReward2.jpeg");
        }
        if (completedGoalsMap.get("Monthly") < 5) {
            rewardsToRemove.add("IMG/MonthlyReward1.jpeg");
        }
        if (completedGoalsMap.get("Monthly") < 10) {
            rewardsToRemove.add("IMG/MonthlyReward2.jpeg");
        }
        if (completedGoalsMap.get("Monthly") < 15) {
            rewardsToRemove.add("IMG/MonthlyReward3.jpeg");
        }
        earnedRewards.removeAll(rewardsToRemove);
    }
}
