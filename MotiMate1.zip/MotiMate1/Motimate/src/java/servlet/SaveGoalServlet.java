package servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.*;
import model.Goal;
import model.User;
import util.DBConnection;

@WebServlet("/save")
public class SaveGoalServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String goalDescription = request.getParameter("goal");
        String type = request.getParameter("type");
        String deadline = request.getParameter("deadline");

        HttpSession session = request.getSession();
        @SuppressWarnings("unchecked")
        Map<String, List<Goal>> goalMap = (Map<String, List<Goal>>) session.getAttribute("goalMap");
        User user = (User) session.getAttribute("user");

        // Check if user is logged in
        if (user == null) {
            request.setAttribute("error", "User not logged in. Please log in to add goals.");
            response.sendRedirect("login.jsp");
            return;
        }

        if (goalMap == null) {
            goalMap = new HashMap<>();
            goalMap.put("Daily", new ArrayList<>());
            goalMap.put("Weekly", new ArrayList<>());
            goalMap.put("Monthly", new ArrayList<>());
            session.setAttribute("goalMap", goalMap);
        }

        // Check maximum goal limits in the database
        Map<String, Integer> maxGoalsMap = new HashMap<>();
        maxGoalsMap.put("Daily", 3);
        maxGoalsMap.put("Weekly", 7);
        maxGoalsMap.put("Monthly", 15);

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                 "SELECT COUNT(*) FROM GOALS WHERE USER_ID = ? AND TYPE = ?")) {
            stmt.setInt(1, user.getUserId());
            stmt.setString(2, type);
            ResultSet rs = stmt.executeQuery();
            if (rs.next() && rs.getInt(1) >= maxGoalsMap.get(type)) {
                request.setAttribute("error", "Maximum number of " + type + " goals (" + maxGoalsMap.get(type) + ") reached.");
                response.setContentType("text/html;charset=UTF-8");
                response.getWriter().println("<script>alert('Maximum number of " + type + " goals (" + maxGoalsMap.get(type) + ") reached.'); window.location='goals.jsp';</script>");
                return;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Database error: Unable to check goal limits.");
            response.sendRedirect("goals.jsp");
            return;
        }

        // Check for duplicate deadline in the database
        boolean duplicateTime = false;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                 "SELECT COUNT(*) FROM GOALS WHERE USER_ID = ? AND TYPE = ? AND DEADLINE = ?")) {
            stmt.setInt(1, user.getUserId());
            stmt.setString(2, type);
            stmt.setTime(3, Time.valueOf(deadline + ":00"));
            ResultSet rs = stmt.executeQuery();
            if (rs.next() && rs.getInt(1) > 0) {
                duplicateTime = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Database error: Unable to check for duplicate deadlines.");
            response.sendRedirect("goals.jsp");
            return;
        }

        if (duplicateTime) {
            request.setAttribute("error", "A goal is already set for this time. Please choose another time.");
            response.setContentType("text/html;charset=UTF-8");
            response.getWriter().println("<script>alert('A goal is already set for this time. Please choose another time.'); window.location='goals.jsp';</script>");
            return;
        }

        if (goalDescription != null && type != null && deadline != null) {
            String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
            int maxCount;
            switch (type) {
                case "Daily":
                    maxCount = 1;
                    break;
                case "Weekly":
                    maxCount = 7;
                    break;
                case "Monthly":
                    maxCount = 30;
                    break;
                default:
                    maxCount = 1;
                    break;
            }
            Goal newGoal = new Goal(goalDescription, timestamp, deadline, maxCount);
            goalMap.get(type).add(newGoal);
            session.setAttribute("goalMap", goalMap);

            // Insert into GOALS table
            try (Connection conn = DBConnection.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(
                     "INSERT INTO GOALS (USER_ID, DESCRIPTION, TYPE, TIMESTAMP, DEADLINE, MAX_COUNT, COMPLETED_COUNT, COMPLETED) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                     PreparedStatement.RETURN_GENERATED_KEYS)) {
                stmt.setInt(1, user.getUserId());
                stmt.setString(2, goalDescription);
                stmt.setString(3, type);
                stmt.setTimestamp(4, java.sql.Timestamp.valueOf(timestamp));
                stmt.setTime(5, Time.valueOf(deadline + ":00"));
                stmt.setInt(6, maxCount);
                stmt.setInt(7, 0);
                stmt.setBoolean(8, false);
                int affectedRows = stmt.executeUpdate();
                if (affectedRows == 0) {
                    throw new SQLException("Inserting goal failed, no rows affected.");
                }
            } catch (SQLException e) {
                e.printStackTrace();
                request.setAttribute("error", "Database error: Unable to save goal - " + e.getMessage());
                response.sendRedirect("goals.jsp");
                return;
            }
        }

        response.sendRedirect("save.jsp");
    }
}