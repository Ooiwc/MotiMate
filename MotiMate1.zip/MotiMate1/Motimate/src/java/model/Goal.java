/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.io.Serializable;

public class Goal implements Serializable, Comparable<Goal> {
    private String description;
    private String timestamp;
    private String deadline;
    private boolean completed;
    private int maxCount;
    private int completedCount;

    public Goal(String description, String timestamp, String deadline, int maxCount) {
        this.description = description;
        this.timestamp = timestamp;
        this.deadline = deadline;
        this.completed = false;
        this.maxCount = maxCount;
        this.completedCount = 0;
    }

    public String getDescription() {
        return description;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public String getDeadline() {
        return deadline;
    }

    public boolean isCompleted() {
        return completed;
    }

    public void setCompleted(boolean completed) {
        this.completed = completed;
    }

    public int getMaxCount() {
        return maxCount;
    }

    public int getCompletedCount() {
        return completedCount;
    }

    public void setCompletedCount(int count) {
        this.completedCount = count;
    }
    
    public void incrementCompletedCount() {
        if (completedCount < maxCount) {
            completedCount++;
        }
    }

    @Override
    public int compareTo(Goal other) {
        return this.timestamp.compareTo(other.timestamp);
    }
}